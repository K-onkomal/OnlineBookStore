import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usercontactus',
  templateUrl: './usercontactus.component.html',
  styleUrls: ['./usercontactus.component.css']
})
export class UsercontactusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
