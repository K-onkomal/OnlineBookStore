import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UserviewbooksComponent } from './userviewbooks/userviewbooks.component';
import { UserbooksinfoComponent } from './userbooksinfo/userbooksinfo.component';
import { UsercartComponent } from './usercart/usercart.component';
import { UserordersComponent } from './userorders/userorders.component';
import { UserdeliveryaddressComponent } from './userdeliveryaddress/userdeliveryaddress.component';
import { UseraboutusComponent } from './useraboutus/useraboutus.component';
import { UsercontactusComponent } from './usercontactus/usercontactus.component';


@NgModule({
  declarations: [
    AppComponent,
    UserloginComponent,
    UsersignupComponent,
    UserhomeComponent,
    UserviewbooksComponent,
    UserbooksinfoComponent,
    UsercartComponent,
    UserordersComponent,
    UserdeliveryaddressComponent,
    UseraboutusComponent,
    UsercontactusComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
