import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UseraboutusComponent } from './useraboutus.component';

describe('UseraboutusComponent', () => {
  let component: UseraboutusComponent;
  let fixture: ComponentFixture<UseraboutusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UseraboutusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UseraboutusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
