import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useraboutus',
  templateUrl: './useraboutus.component.html',
  styleUrls: ['./useraboutus.component.css']
})
export class UseraboutusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
