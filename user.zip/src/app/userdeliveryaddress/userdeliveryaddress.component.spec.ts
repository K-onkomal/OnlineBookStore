import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserdeliveryaddressComponent } from './userdeliveryaddress.component';

describe('UserdeliveryaddressComponent', () => {
  let component: UserdeliveryaddressComponent;
  let fixture: ComponentFixture<UserdeliveryaddressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserdeliveryaddressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserdeliveryaddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
