import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from'@angular/router';
import{FormsModule, NgForm}from '@angular/forms';
import {NgModule} from '@angular/core';
@Component({
  selector: 'app-userdeliveryaddress',
  templateUrl: './userdeliveryaddress.component.html',
  styleUrls: ['./userdeliveryaddress.component.css']
})
export class UserdeliveryaddressComponent implements OnInit {
username:String;
mobilenumber: String;  
  deliveryaddress:String;
  constructor() { }

  onSubmit(form: NgForm) {
    if (form.valid) {

      console.log(form.value);

    }

  }
  ngOnInit() {
  }

}
