import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from'@angular/router';
import{FormsModule, NgForm}from '@angular/forms';
import {NgModule} from '@angular/core';
@Component({
  selector: 'app-userbooksinfo',
  templateUrl: './userbooksinfo.component.html',
  styleUrls: ['./userbooksinfo.component.css']
})
export class UserbooksinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
