import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserbooksinfoComponent } from './userbooksinfo.component';

describe('UserbooksinfoComponent', () => {
  let component: UserbooksinfoComponent;
  let fixture: ComponentFixture<UserbooksinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserbooksinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserbooksinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
