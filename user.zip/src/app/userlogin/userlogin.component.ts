import { Component, OnInit } from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';
import {Router,ActivatedRoute} from'@angular/router';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
email: String;
   password: String;
  constructor() { }

  
  onSubmit(form: NgForm) {
    if (form.valid) {

      console.log(form.value);

    }

  }

  ngOnInit() {
  }

}
