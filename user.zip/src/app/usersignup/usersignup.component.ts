import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';
@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
  username: String;
  email: String;
  password: String;
  confirmpassword: String;
  constructor() {}
  onSubmit(form: NgForm) {
    if (form.valid) {

      console.log(form.value);

    }

  }

  ngOnInit() {
  }

}
